import importlib.util
from pathlib import Path
import tempfile
import unittest


MODULE_PATH = Path(__file__).resolve().parents[1] / "prepare_config.py"
SPEC = importlib.util.spec_from_file_location("prepare_config", MODULE_PATH)
prepare_config = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(prepare_config)


class TestPrinterCfg(unittest.TestCase):
    def test_adds_managed_includes_after_base(self):
        original = "[include printer.base.cfg] # Base\n[include client.cfg]\n"
        updated = prepare_config.update_printer_cfg(original)
        self.assertIn(prepare_config.PRINTER_BEGIN, updated)
        self.assertLess(
            updated.index("[include printer.base.cfg]"),
            updated.index("[include canvas-hardware-ad5m.cfg]"),
        )
        self.assertEqual(updated, prepare_config.update_printer_cfg(updated))

    def test_rejects_unmanaged_canvas_include(self):
        original = "[include printer.base.cfg]\n[include canvas-hardware-ad5m.cfg]\n"
        with self.assertRaises(prepare_config.ConfigError):
            prepare_config.update_printer_cfg(original)


class TestPrinterBaseCfg(unittest.TestCase):
    STOCK = """[gcode_button _e1_sensor_input]
pin: !PE1

# Filament runout sensor
[filament_switch_sensor runout_sensor]
pause_on_runout: False
switch_pin: !PB14
event_delay: 1.0
runout_gcode:
    _FILAMENT_RUNOUT_EVENT

[servo my_servo]
pin: PC9
"""

    def test_replaces_recognised_stock_sensor(self):
        updated = prepare_config.update_printer_base_cfg(self.STOCK)
        self.assertIn(prepare_config.RUNOUT_BEGIN, updated)
        self.assertNotIn("[filament_switch_sensor runout_sensor]", updated)
        self.assertEqual(updated, prepare_config.update_printer_base_cfg(updated))

    def test_rejects_changed_sensor_pin(self):
        changed = self.STOCK.replace("switch_pin: !PB14", "switch_pin: PB14")
        with self.assertRaises(prepare_config.ConfigError):
            prepare_config.update_printer_base_cfg(changed)


class TestMacrosCfg(unittest.TestCase):
    def test_replaces_resume_sensor_reference(self):
        original = (
            "[gcode_macro _CLIENT_VARIABLE]\n"
            'variable_runout_sensor    : "filament_switch_sensor runout_sensor"\n'
            "gcode:\n"
        )
        updated = prepare_config.update_macros_cfg(original)
        self.assertIn('variable_runout_sensor    : ""', updated)
        self.assertEqual(updated, prepare_config.update_macros_cfg(updated))

    def test_rejects_custom_sensor_reference(self):
        original = (
            "[gcode_macro _CLIENT_VARIABLE]\n"
            'variable_runout_sensor: "filament_switch_sensor custom"\n'
        )
        with self.assertRaises(prepare_config.ConfigError):
            prepare_config.update_macros_cfg(original)


class TestAtomicApply(unittest.TestCase):
    def test_writes_all_three_files(self):
        base = TestPrinterBaseCfg.STOCK
        printer = "[include printer.base.cfg]\n[include client.cfg]\n"
        macros = (
            "[gcode_macro _CLIENT_VARIABLE]\n"
            'variable_runout_sensor    : "filament_switch_sensor runout_sensor"\n'
            "gcode:\n"
        )
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            files = {
                "printer.cfg": (printer, prepare_config.update_printer_cfg),
                "printer.base.cfg": (base, prepare_config.update_printer_base_cfg),
                "macros.cfg": (macros, prepare_config.update_macros_cfg),
            }
            for name, (content, _updater) in files.items():
                (directory / name).write_text(content, encoding="utf-8")
            for name, (_content, updater) in files.items():
                path = directory / name
                prepare_config._atomic_write(path, updater(path.read_text()))
            self.assertIn(
                prepare_config.PRINTER_BEGIN,
                (directory / "printer.cfg").read_text(),
            )
            self.assertIn(
                prepare_config.RUNOUT_BEGIN,
                (directory / "printer.base.cfg").read_text(),
            )
            self.assertIn(
                prepare_config.MACRO_BEGIN,
                (directory / "macros.cfg").read_text(),
            )


if __name__ == "__main__":
    unittest.main()
