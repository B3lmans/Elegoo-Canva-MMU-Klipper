#!/bin/sh

# Restore files captured immediately before the CANVAS host add-on was installed.

set -eu

CONFIG_DIR="/root/printer_data/config"
KLIPPER_INIT="/etc/init.d/S60klipper"
MARKER="$CONFIG_DIR/.canvas-host-addon-backup"
BACKUP_DIR=""
ASSUME_YES=0
KLIPPER_STOPPED=0

usage() {
    cat <<'EOF'
Usage: sh restore-canvas-host.sh [--backup /root/canvas-host-backups/...] [--yes]

Without --backup, the successful install marker selects the recovery backup.
EOF
}

die() {
    echo "ERROR: $*" >&2
    exit 1
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --backup)
            [ "$#" -ge 2 ] || die "--backup requires a path"
            BACKUP_DIR=$2
            shift 2
            ;;
        --yes)
            ASSUME_YES=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

[ "$(id -u)" -eq 0 ] || die "Run this script as root on the AD5M"
[ -x "$KLIPPER_INIT" ] || die "Klipper Mod startup script is missing"
command -v python3 >/dev/null 2>&1 || die "python3 is required"

if [ -z "$BACKUP_DIR" ]; then
    [ -f "$MARKER" ] || die "No successful CANVAS host installation marker was found"
    BACKUP_DIR=$(sed -n '1p' "$MARKER")
fi

case "$BACKUP_DIR" in
    /root/canvas-host-backups/*)
        ;;
    *)
        die "Backup must be inside /root/canvas-host-backups"
        ;;
esac
[ -d "$BACKUP_DIR" ] || die "Backup directory does not exist: $BACKUP_DIR"
[ -f "$BACKUP_DIR/manifest.tsv" ] || die "Backup manifest is missing"

tab=$(printf '\t')
while IFS="$tab" read -r state target; do
    [ -n "$target" ] || continue
    case "$target" in
        /root/printer_data/config/*|/root/printer_software/klipper/klippy/*)
            ;;
        *)
            die "Refusing unexpected restore target: $target"
            ;;
    esac
    case "$state" in
        present)
            [ -f "$BACKUP_DIR/files$target" ] \
                || die "Backup file is missing: $BACKUP_DIR/files$target"
            ;;
        missing)
            ;;
        *)
            die "Invalid backup manifest state: $state"
            ;;
    esac
done < "$BACKUP_DIR/manifest.tsv"

restart_if_needed() {
    status=$?
    trap - EXIT HUP INT TERM
    if [ "$status" -ne 0 ] && [ "$KLIPPER_STOPPED" -eq 1 ]; then
        echo "Restore stopped unexpectedly; attempting to start Klipper..." >&2
        "$KLIPPER_INIT" start >/dev/null 2>&1 || true
    fi
    exit "$status"
}
trap restart_if_needed EXIT
trap 'exit 130' HUP INT TERM

print_state=$(python3 - <<'PY'
import json
import urllib.request

url = "http://127.0.0.1:7125/printer/objects/query?print_stats"
try:
    with urllib.request.urlopen(url, timeout=5) as response:
        data = json.load(response)
    print(data["result"]["status"]["print_stats"]["state"])
except Exception as exc:
    print(f"unavailable:{exc}")
PY
)
case "$print_state" in
    printing|paused)
        die "Printer state is $print_state; finish or cancel the job first"
        ;;
    unavailable:*)
        die "Moonraker status is unavailable: ${print_state#unavailable:}"
        ;;
esac

echo "Restore source: $BACKUP_DIR"
echo "Printer state: $print_state"
if [ "$ASSUME_YES" -ne 1 ]; then
    printf '\nType RESTORE CANVAS HOST to continue: '
    IFS= read -r confirmation
    [ "$confirmation" = "RESTORE CANVAS HOST" ] \
        || die "Confirmation did not match; nothing changed"
fi

echo "Stopping Klipper..."
"$KLIPPER_INIT" stop
KLIPPER_STOPPED=1

while IFS="$tab" read -r state target; do
    [ -n "$target" ] || continue
    case "$target" in
        /root/printer_data/config/*|/root/printer_software/klipper/klippy/*)
            ;;
        *)
            die "Refusing unexpected restore target: $target"
            ;;
    esac
    if [ "$state" = "present" ]; then
        source_file="$BACKUP_DIR/files$target"
        [ -f "$source_file" ] || die "Backup file is missing: $source_file"
        mkdir -p "$(dirname "$target")"
        cp -p "$source_file" "$target"
    elif [ "$state" = "missing" ]; then
        rm -f -- "$target"
    else
        die "Invalid backup manifest state: $state"
    fi
done < "$BACKUP_DIR/manifest.tsv"

rm -f -- "$MARKER"
echo "Starting restored Klipper configuration..."
"$KLIPPER_INIT" start
KLIPPER_STOPPED=0

attempt=0
while [ "$attempt" -lt 45 ]; do
    if python3 - <<'PY'
import json
import urllib.request

try:
    url = "http://127.0.0.1:7125/printer/objects/query?webhooks"
    with urllib.request.urlopen(url, timeout=3) as response:
        state = json.load(response)["result"]["status"]["webhooks"]["state"]
    raise SystemExit(0 if state == "ready" else 1)
except Exception:
    raise SystemExit(1)
PY
    then
        echo
        echo "SUCCESS: the pre-installation Klipper files were restored."
        echo "The recovery backup was retained at $BACKUP_DIR"
        exit 0
    fi
    attempt=$((attempt + 1))
    sleep 1
done

die "Restored Klipper did not become ready within 45 seconds; backup is retained"
