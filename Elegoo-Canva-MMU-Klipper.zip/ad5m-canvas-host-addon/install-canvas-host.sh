#!/bin/sh

# Guarded host-side CANVAS integration for AD5M Klipper Mod v00.05-beta.

set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PAYLOAD_DIR="$SCRIPT_DIR/payload"
CONFIG_DIR="/root/printer_data/config"
KLIPPER_DIR="/root/printer_software/klipper"
KLIPPER_INIT="/etc/init.d/S60klipper"
MSGPROTO="$KLIPPER_DIR/klippy/msgproto.py"
EXPECTED_VERSION="v0.11.0-4-g4d24de080-AD5M-20240506"
BASE_MSGPROTO_SHA256="2d384b7fd92370d233f8031225499ffa37266dd2a54fdef2f8c416b498d30fc5"
ADDON_MSGPROTO_SHA256="e3e907fc8422f678394b5ab506e59bfb9b7fc034212075969768cfe9de036d89"
CHECK_ONLY=0
ASSUME_YES=0
BACKUP_DIR=""
FILE_LIST=""
ROLLBACK_NEEDED=0
COMMITTED=0

usage() {
    cat <<'EOF'
Usage: sh install-canvas-host.sh [--check] [--yes]

--check validates the AD5M, CANVAS and current configuration without writing.
--yes skips the interactive phrase and is intended only for controlled tests.
EOF
}

die() {
    echo "ERROR: $*" >&2
    exit 1
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --check)
            CHECK_ONLY=1
            shift
            ;;
        --yes)
            ASSUME_YES=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

restore_backup() {
    backup=$1
    manifest="$backup/manifest.tsv"
    [ -f "$manifest" ] || return 1
    tab=$(printf '\t')
    while IFS="$tab" read -r state target; do
        [ -n "$target" ] || continue
        case "$target" in
            /root/printer_data/config/*|/root/printer_software/klipper/klippy/*)
                ;;
            *)
                echo "Refusing unexpected restore target: $target" >&2
                return 1
                ;;
        esac
        if [ "$state" = "present" ]; then
            source_file="$backup/files$target"
            [ -f "$source_file" ] || return 1
            mkdir -p "$(dirname "$target")"
            cp -p "$source_file" "$target"
        elif [ "$state" = "missing" ]; then
            rm -f -- "$target"
        else
            echo "Invalid backup manifest state: $state" >&2
            return 1
        fi
    done < "$manifest"
}

cleanup() {
    status=$?
    trap - EXIT HUP INT TERM
    set +e
    if [ "$status" -ne 0 ] && [ "$ROLLBACK_NEEDED" -eq 1 ]; then
        echo
        echo "Installation failed; restoring the pre-installation files..." >&2
        "$KLIPPER_INIT" stop >/dev/null 2>&1
        if restore_backup "$BACKUP_DIR"; then
            "$KLIPPER_INIT" start >/dev/null 2>&1
            echo "Rollback completed. Backup retained at $BACKUP_DIR" >&2
        else
            echo "AUTOMATIC ROLLBACK FAILED. Backup retained at $BACKUP_DIR" >&2
        fi
    fi
    if [ -n "$FILE_LIST" ]; then
        rm -f -- "$FILE_LIST"
    fi
    exit "$status"
}
trap cleanup EXIT
trap 'exit 130' HUP INT TERM

find_single_acm() {
    set -- /dev/ttyACM*
    if [ "$1" = '/dev/ttyACM*' ]; then
        die "No /dev/ttyACM device found. Check CANVAS power and USB wiring."
    fi
    [ "$#" -eq 1 ] || die "Multiple ACM devices found; disconnect unrelated USB MCUs."
    printf '%s\n' "$1"
}

usb_attr() {
    device=$1
    attribute=$2
    resolved=$(readlink -f "$device" 2>/dev/null || true)
    [ -n "$resolved" ] || return 1
    tty_name=$(basename "$resolved")
    node=$(readlink -f "/sys/class/tty/$tty_name/device" 2>/dev/null || true)
    while [ -n "$node" ] && [ "$node" != "/" ]; do
        if [ -r "$node/$attribute" ]; then
            cat "$node/$attribute"
            return 0
        fi
        parent=$(dirname "$node")
        [ "$parent" != "$node" ] || break
        node=$parent
    done
    return 1
}

json_object_file() {
    python3 - "$1" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
try:
    value = json.loads(path.read_text(encoding="utf-8"))
except (OSError, UnicodeError, json.JSONDecodeError):
    raise SystemExit(1)
raise SystemExit(0 if isinstance(value, dict) else 1)
PY
}

moonraker_print_state() {
    python3 - <<'PY'
import json
import urllib.request

url = "http://127.0.0.1:7125/printer/objects/query?print_stats"
try:
    with urllib.request.urlopen(url, timeout=5) as response:
        data = json.load(response)
    print(data["result"]["status"]["print_stats"]["state"])
except Exception as exc:
    print(f"unavailable:{exc}")
PY
}

moonraker_canvas_ready() {
    python3 - <<'PY'
import json
import urllib.request

url = "http://127.0.0.1:7125/printer/objects/query?webhooks&mcu%20canvas&AFC"
try:
    with urllib.request.urlopen(url, timeout=3) as response:
        status = json.load(response)["result"]["status"]
    ready = status.get("webhooks", {}).get("state") == "ready"
    canvas = "mcu canvas" in status
    afc = "AFC" in status
    raise SystemExit(0 if ready and canvas and afc else 1)
except Exception:
    raise SystemExit(1)
PY
}

payload_target() {
    source_file=$1
    relative=${source_file#"$PAYLOAD_DIR/root/"}
    printf '/root/%s\n' "$relative"
}

payload_is_installed() {
    grep -q '^# BEGIN AD5M CANVAS HOST ADD-ON INCLUDES$' "$CONFIG_DIR/printer.cfg" \
        || return 1
    grep -q '^# BEGIN AD5M CANVAS HOST ADD-ON PB14 OWNERSHIP$' \
        "$CONFIG_DIR/printer.base.cfg" || return 1
    grep -q '^# BEGIN AD5M CANVAS HOST ADD-ON RESUME GUARD$' \
        "$CONFIG_DIR/macros.cfg" || return 1
    [ "$(sha256sum "$MSGPROTO" | awk '{print $1}')" = "$ADDON_MSGPROTO_SHA256" ] \
        || return 1
    while IFS= read -r source_file; do
        target=$(payload_target "$source_file")
        case "$target" in
            */AFC.var|*/AFC.var.unit)
                continue
                ;;
        esac
        [ -f "$target" ] || return 1
        source_hash=$(sha256sum "$source_file" | awk '{print $1}')
        target_hash=$(sha256sum "$target" | awk '{print $1}')
        [ "$source_hash" = "$target_hash" ] || return 1
    done < "$FILE_LIST"
    return 0
}

backup_one() {
    target=$1
    if [ -e "$target" ]; then
        mkdir -p "$BACKUP_DIR/files$(dirname "$target")"
        cp -p "$target" "$BACKUP_DIR/files$target"
        printf 'present\t%s\n' "$target" >> "$BACKUP_DIR/manifest.tsv"
    else
        printf 'missing\t%s\n' "$target" >> "$BACKUP_DIR/manifest.tsv"
    fi
}

[ "$(id -u)" -eq 0 ] || die "Run this script as root on the AD5M"
[ "$(uname -m)" = "armv7l" ] || die "This add-on supports only the ARMv7 AD5M"
command -v python3 >/dev/null 2>&1 || die "python3 is required"
command -v sha256sum >/dev/null 2>&1 || die "sha256sum is required"
[ -x "$KLIPPER_INIT" ] || die "Klipper Mod startup script is missing: $KLIPPER_INIT"
[ -f "$MSGPROTO" ] || die "Klipper msgproto.py is missing"
[ -d "$CONFIG_DIR" ] || die "Printer configuration directory is missing"
[ -f "$SCRIPT_DIR/PAYLOAD_SHA256SUMS.txt" ] || die "Payload checksum file is missing"
[ -f "$SCRIPT_DIR/prepare_config.py" ] || die "Configuration helper is missing"

echo "Verifying the bundled host payload..."
(cd "$SCRIPT_DIR" && sha256sum -c PAYLOAD_SHA256SUMS.txt)

FILE_LIST=$(mktemp /tmp/canvas-host-files.XXXXXX)
find "$PAYLOAD_DIR/root" -type f | sort > "$FILE_LIST"
[ -s "$FILE_LIST" ] || die "The host payload is empty"

if ! grep -q "Git version: '$EXPECTED_VERSION'" /root/printer_data/logs/klipper.log; then
    die "Expected AD5M Klipper $EXPECTED_VERSION was not found in klipper.log"
fi

current_msgproto=$(sha256sum "$MSGPROTO" | awk '{print $1}')
case "$current_msgproto" in
    "$BASE_MSGPROTO_SHA256"|"$ADDON_MSGPROTO_SHA256")
        ;;
    *)
        die "Unsupported or modified Klipper msgproto.py ($current_msgproto)"
        ;;
esac

DEVICE=$(find_single_acm)
vendor=$(usb_attr "$DEVICE" idVendor | tr 'A-F' 'a-f')
product_id=$(usb_attr "$DEVICE" idProduct | tr 'A-F' 'a-f')
product_name=$(usb_attr "$DEVICE" product 2>/dev/null || true)
echo "Detected CANVAS device: $DEVICE"
echo "Detected USB identity:  $vendor:$product_id ($product_name)"
[ "$vendor:$product_id" = "1d50:614e" ] \
    || die "CANVAS must already run the verified Klipper USB firmware"
[ "$(printf '%s' "$product_name" | tr 'A-Z' 'a-z')" = "stm32f401xc" ] \
    || die "Expected the verified CC1 CANVAS STM32F401XC identity"

python3 "$SCRIPT_DIR/prepare_config.py" --config-dir "$CONFIG_DIR" --check

while IFS= read -r source_file; do
    target=$(payload_target "$source_file")
    case "$target" in
        "$MSGPROTO"|*/AFC.var|*/AFC.var.unit)
            continue
            ;;
    esac
    if [ -e "$target" ]; then
        source_hash=$(sha256sum "$source_file" | awk '{print $1}')
        target_hash=$(sha256sum "$target" | awk '{print $1}')
        [ "$source_hash" = "$target_hash" ] \
            || die "Existing file conflicts with the add-on: $target"
    fi
done < "$FILE_LIST"

for state_file in "$CONFIG_DIR/AFC.var" "$CONFIG_DIR/AFC.var.unit"; do
    if [ -e "$state_file" ]; then
        json_object_file "$state_file" \
            || die "Existing AFC state is not a JSON object: $state_file"
    fi
done

print_state=$(moonraker_print_state)
case "$print_state" in
    printing|paused)
        die "Printer state is $print_state; finish or cancel the job first"
        ;;
    unavailable:*)
        die "Moonraker status is unavailable: ${print_state#unavailable:}"
        ;;
esac
echo "Printer state:          $print_state"

if payload_is_installed; then
    echo
    echo "The CANVAS host add-on is already installed and matches this bundle."
    echo "Nothing was changed."
    exit 0
fi

if [ "$CHECK_ONLY" -eq 1 ]; then
    echo
    echo "CHECK PASSED: this AD5M is compatible with the guarded CANVAS host add-on."
    echo "No files were changed."
    exit 0
fi

cat <<'EOF'

This installs CANVAS host support into the existing AD5M Klipper Mod.
It preserves printer.cfg calibration values and creates a complete backup.

The stock PB14 runout-sensor section will be disabled because AFC must own
that physical input. Automatic tool changes remain commissioning-locked.
The lane insertion/prime behaviour is enabled after Klipper starts.
EOF

if [ "$ASSUME_YES" -ne 1 ]; then
    printf '\nType INSTALL CANVAS HOST to continue: '
    IFS= read -r confirmation
    [ "$confirmation" = "INSTALL CANVAS HOST" ] \
        || die "Confirmation did not match; nothing changed"
fi

umask 077
BACKUP_DIR="/root/canvas-host-backups/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$BACKUP_DIR/files"
: > "$BACKUP_DIR/manifest.tsv"

while IFS= read -r source_file; do
    backup_one "$(payload_target "$source_file")"
done < "$FILE_LIST"
backup_one "$CONFIG_DIR/printer.cfg"
backup_one "$CONFIG_DIR/printer.base.cfg"
backup_one "$CONFIG_DIR/macros.cfg"

ROLLBACK_NEEDED=1
echo "Backup created:         $BACKUP_DIR"
echo "Stopping Klipper..."
"$KLIPPER_INIT" stop

while IFS= read -r source_file; do
    target=$(payload_target "$source_file")
    case "$target" in
        */AFC.var|*/AFC.var.unit)
            if [ -e "$target" ]; then
                continue
            fi
            ;;
    esac
    mkdir -p "$(dirname "$target")"
    cp "$source_file" "$target"
    chmod 0644 "$target"
done < "$FILE_LIST"

python3 "$SCRIPT_DIR/prepare_config.py" --config-dir "$CONFIG_DIR" --apply

echo "Starting Klipper with CANVAS support..."
"$KLIPPER_INIT" start

attempt=0
while [ "$attempt" -lt 45 ]; do
    if moonraker_canvas_ready; then
        COMMITTED=1
        ROLLBACK_NEEDED=0
        printf '%s\n' "$BACKUP_DIR" > "$CONFIG_DIR/.canvas-host-addon-backup"
        chmod 0600 "$CONFIG_DIR/.canvas-host-addon-backup"
        echo
        echo "SUCCESS: Klipper is ready with the CANVAS MCU and AFC loaded."
        echo "Recovery backup: $BACKUP_DIR"
        echo "Keep every commissioning_lock enabled until mechanical calibration."
        exit 0
    fi
    attempt=$((attempt + 1))
    sleep 1
done

die "Klipper did not become ready with both CANVAS and AFC within 45 seconds"
