param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$PrinterIp,

    [switch]$CheckOnly
)

$ErrorActionPreference = 'Stop'
$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifestPath = Join-Path $bundle 'SHA256SUMS.txt'
$ssh = Get-Command ssh.exe -ErrorAction Stop
$scp = Get-Command scp.exe -ErrorAction Stop

if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'Missing bundle checksum file: SHA256SUMS.txt'
}

Write-Host 'Checking the local AD5M CANVAS host add-on bundle...'
$manifestLines = Get-Content -LiteralPath $manifestPath
foreach ($line in $manifestLines) {
    if ($line -notmatch '^([0-9a-fA-F]{64})  (.+)$') {
        throw "Invalid checksum manifest line: $line"
    }
    $expected = $Matches[1]
    $relative = $Matches[2].Replace('/', [IO.Path]::DirectorySeparatorChar)
    $path = Join-Path $bundle $relative
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing bundle file: $relative"
    }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash
    if ($actual -ne $expected) {
        throw "SHA-256 mismatch for $relative"
    }
}

$knownHosts = Join-Path ([IO.Path]::GetTempPath()) 'ad5m-canvas-known-hosts'
$connectionOptions = @(
    '-o', "UserKnownHostsFile=$knownHosts",
    '-o', 'StrictHostKeyChecking=accept-new'
)

Write-Host ''
Write-Host "Uploading the host add-on to root@$PrinterIp..."
Write-Host 'The usual AD5M Klipper Mod SSH password is klipper.'
& $scp.Source @connectionOptions -O -r $bundle "root@${PrinterIp}:/root/"
if ($LASTEXITCODE -ne 0) {
    throw "SCP upload failed with exit code $LASTEXITCODE"
}

$remoteCommand = 'sh /root/ad5m-canvas-host-addon/install-canvas-host.sh'
if ($CheckOnly) {
    $remoteCommand += ' --check'
}

Write-Host ''
if ($CheckOnly) {
    Write-Host 'Running the non-writing compatibility check on the AD5M...'
} else {
    Write-Host 'Starting the guarded CANVAS host installation on the AD5M...'
}
& $ssh.Source @connectionOptions -t "root@$PrinterIp" $remoteCommand
if ($LASTEXITCODE -ne 0) {
    throw "Remote CANVAS host installer returned exit code $LASTEXITCODE"
}

Write-Host ''
if ($CheckOnly) {
    Write-Host 'Remote compatibility check completed.'
} else {
    Write-Host 'Remote CANVAS host installation completed.'
}
