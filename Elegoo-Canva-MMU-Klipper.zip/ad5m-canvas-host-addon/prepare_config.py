#!/usr/bin/env python3
"""Validate and apply the small config edits required by the CANVAS add-on."""

import argparse
import os
from pathlib import Path
import re
import sys
from typing import Callable


PRINTER_BEGIN = "# BEGIN AD5M CANVAS HOST ADD-ON INCLUDES"
PRINTER_END = "# END AD5M CANVAS HOST ADD-ON INCLUDES"
PRINTER_BLOCK = [
    PRINTER_BEGIN,
    "[include canvas-hardware-ad5m.cfg] # CANVAS MCU and DRV8833 hardware",
    "[include afc-canvas-ad5m.cfg] # AFC/CANVAS commissioning configuration",
    PRINTER_END,
]

RUNOUT_BEGIN = "# BEGIN AD5M CANVAS HOST ADD-ON PB14 OWNERSHIP"
RUNOUT_END = "# END AD5M CANVAS HOST ADD-ON PB14 OWNERSHIP"
RUNOUT_BLOCK = [
    RUNOUT_BEGIN,
    "# PB14 is now owned by [AFC_extruder extruder].",
    "# The original runout-sensor section is retained in the installer backup.",
    RUNOUT_END,
]

MACRO_BEGIN = "# BEGIN AD5M CANVAS HOST ADD-ON RESUME GUARD"
MACRO_END = "# END AD5M CANVAS HOST ADD-ON RESUME GUARD"
MACRO_BLOCK = [
    MACRO_BEGIN,
    "# AFC owns PB14; do not query the removed stock sensor during RESUME.",
    'variable_runout_sensor    : ""',
    MACRO_END,
]


class ConfigError(RuntimeError):
    """Raised when the source configuration is not the supported AD5M layout."""


def _split(text: str) -> list[str]:
    return text.replace("\r\n", "\n").replace("\r", "\n").splitlines()


def _join(lines: list[str]) -> str:
    return "\n".join(lines) + "\n"


def _managed_block_is_exact(
    lines: list[str], begin: str, end: str, expected: list[str]
) -> bool:
    if lines.count(begin) != 1 or lines.count(end) != 1:
        return False
    start = lines.index(begin)
    finish = lines.index(end, start) + 1
    return lines[start:finish] == expected


def update_printer_cfg(text: str) -> str:
    lines = _split(text)
    if PRINTER_BEGIN in lines or PRINTER_END in lines:
        if not _managed_block_is_exact(
            lines, PRINTER_BEGIN, PRINTER_END, PRINTER_BLOCK
        ):
            raise ConfigError("The managed include block was modified or is incomplete")
        return _join(lines)

    target_names = ("canvas-hardware-ad5m.cfg", "afc-canvas-ad5m.cfg")
    if any(any(name in line for name in target_names) for line in lines):
        raise ConfigError("A CANVAS include exists outside the managed block")

    base_pattern = re.compile(r"^\s*\[include\s+printer\.base\.cfg\]", re.I)
    indexes = [index for index, line in enumerate(lines) if base_pattern.match(line)]
    if len(indexes) != 1:
        raise ConfigError("Expected exactly one [include printer.base.cfg] line")
    insert_at = indexes[0] + 1
    lines[insert_at:insert_at] = PRINTER_BLOCK
    return _join(lines)


def _section_bounds(lines: list[str], section_name: str) -> tuple[int, int]:
    header_pattern = re.compile(r"^\s*\[([^]]+)\]\s*(?:#.*)?$")
    matches: list[tuple[int, str]] = []
    for index, line in enumerate(lines):
        match = header_pattern.match(line)
        if match:
            matches.append((index, match.group(1).strip().lower()))

    starts = [index for index, name in matches if name == section_name.lower()]
    if len(starts) != 1:
        raise ConfigError(f"Expected exactly one [{section_name}] section")
    start = starts[0]
    end = len(lines)
    for index, _name in matches:
        if index > start:
            end = index
            break
    while end > start and not lines[end - 1].strip():
        end -= 1
    return start, end


def _normalise_runout(lines: list[str]) -> list[str]:
    normalised = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        normalised.append(re.sub(r"\s+", "", stripped).lower())
    return normalised


def update_printer_base_cfg(text: str) -> str:
    lines = _split(text)
    section_name = "filament_switch_sensor runout_sensor"
    if RUNOUT_BEGIN in lines or RUNOUT_END in lines:
        if not _managed_block_is_exact(lines, RUNOUT_BEGIN, RUNOUT_END, RUNOUT_BLOCK):
            raise ConfigError("The managed PB14 block was modified or is incomplete")
        active_header = re.compile(
            r"^\s*\[filament_switch_sensor\s+runout_sensor\]", re.I
        )
        if any(active_header.match(line) for line in lines):
            raise ConfigError("The stock runout sensor is still active")
        return _join(lines)

    start, end = _section_bounds(lines, section_name)
    actual = _normalise_runout(lines[start:end])
    expected = [
        "[filament_switch_sensorrunout_sensor]",
        "pause_on_runout:false",
        "switch_pin:!pb14",
        "event_delay:1.0",
        "runout_gcode:",
        "_filament_runout_event",
    ]
    if actual != expected:
        raise ConfigError("The stock PB14 runout-sensor section is not recognised")

    lines[start:end] = RUNOUT_BLOCK
    return _join(lines)


def update_macros_cfg(text: str) -> str:
    lines = _split(text)
    if MACRO_BEGIN in lines or MACRO_END in lines:
        if not _managed_block_is_exact(lines, MACRO_BEGIN, MACRO_END, MACRO_BLOCK):
            raise ConfigError("The managed RESUME guard was modified or is incomplete")
        return _join(lines)

    pattern = re.compile(
        r'^\s*variable_runout_sensor\s*:\s*"filament_switch_sensor runout_sensor"\s*$'
    )
    indexes = [index for index, line in enumerate(lines) if pattern.match(line)]
    if len(indexes) != 1:
        raise ConfigError("The stock client runout-sensor variable is not recognised")
    index = indexes[0]
    lines[index:index + 1] = MACRO_BLOCK
    return _join(lines)


def _atomic_write(path: Path, content: str) -> None:
    temporary = path.with_name(f".{path.name}.canvas-host.tmp")
    mode = path.stat().st_mode
    try:
        temporary.write_text(content, encoding="utf-8", newline="\n")
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config-dir", type=Path, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check", action="store_true")
    action.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    operations: list[tuple[Path, Callable[[str], str]]] = [
        (args.config_dir / "printer.cfg", update_printer_cfg),
        (args.config_dir / "printer.base.cfg", update_printer_base_cfg),
        (args.config_dir / "macros.cfg", update_macros_cfg),
    ]
    updates: list[tuple[Path, str]] = []
    try:
        for path, updater in operations:
            if not path.is_file():
                raise ConfigError(f"Required configuration file is missing: {path}")
            updates.append((path, updater(path.read_text(encoding="utf-8"))))
    except (ConfigError, OSError, UnicodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    if args.apply:
        for path, content in updates:
            _atomic_write(path, content)
        print("Applied guarded CANVAS edits to printer.cfg, printer.base.cfg and macros.cfg")
    else:
        print("Configuration layout is compatible with the guarded CANVAS edits")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
