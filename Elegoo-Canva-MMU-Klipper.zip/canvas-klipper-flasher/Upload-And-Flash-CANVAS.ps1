param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$PrinterIp
)

$ErrorActionPreference = 'Stop'
$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path
$ssh = Get-Command ssh.exe -ErrorAction Stop
$scp = Get-Command scp.exe -ErrorAction Stop

$expected = @{
    'mcu-flasher-linux-armv7' = '49D9A49D6B7422BA97BC5DCFC8E2674ABECB9B19A2D173C4E2ED704B85B00DB8'
    'flashtool.py' = '918DE11F9310D434E32AEB0020A767F7900E9BA703A7F26F44874D8DE1D0C126'
    'katapult-deployer-canvas.bin' = '8759BBFBE4D114A38338E36ADC582528B194B9325C29E0A2CB3A07D526AAF828'
    'klipper-canvas.bin' = 'DE56B678D544A2C8620E5D96BFDB6D4E3DA42319E008EB6E9459000B7E0B6FB4'
}

Write-Host 'Checking the local CANVAS firmware bundle...'
foreach ($name in $expected.Keys) {
    $path = Join-Path $bundle $name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing bundle file: $name"
    }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash
    if ($actual -ne $expected[$name]) {
        throw "SHA-256 mismatch for $name"
    }
}

Write-Host ''
Write-Host "Uploading the flasher to root@$PrinterIp..."
Write-Host 'SSH may ask for the printer password. The usual AD5M Klipper Mod password is klipper.'
& $scp.Source -O -r $bundle "root@${PrinterIp}:/root/"
if ($LASTEXITCODE -ne 0) {
    throw "SCP upload failed with exit code $LASTEXITCODE"
}

Write-Host ''
Write-Host 'Starting the guarded flasher on the AD5M...'
& $ssh.Source -t "root@$PrinterIp" 'sh /root/canvas-klipper-flasher/flash-canvas.sh'
if ($LASTEXITCODE -ne 0) {
    throw "Remote CANVAS flasher returned exit code $LASTEXITCODE"
}

Write-Host ''
Write-Host 'Remote flashing process completed.'
