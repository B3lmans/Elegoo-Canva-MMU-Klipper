#!/bin/sh

# First-time Elegoo CANVAS -> Katapult -> Klipper flasher for an AD5M host.
# The command sequence matches OpenCentauri's CANVAS firmware init script.

set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEVICE_ARG=""
ASSUME_YES=0

usage() {
    cat <<'EOF'
Usage: sh flash-canvas.sh [--device /dev/ttyACM0] [--yes]

The normal first-time operation is interactive. --yes is intended only for a
controlled automated test after the device path and wiring have been checked.
EOF
}

die() {
    echo "ERROR: $*" >&2
    exit 1
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --device)
            [ "$#" -ge 2 ] || die "--device requires a path"
            DEVICE_ARG=$2
            shift 2
            ;;
        --yes)
            ASSUME_YES=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

[ "$(id -u)" -eq 0 ] || die "Run this script as root on the AD5M"
[ "$(uname -m)" = "armv7l" ] || die "This bundle is only for an ARMv7 AD5M host"
command -v python3 >/dev/null 2>&1 || die "python3 is required"
command -v sha256sum >/dev/null 2>&1 || die "sha256sum is required"

for required in \
    mcu-flasher-linux-armv7 \
    flashtool.py \
    katapult-deployer-canvas.bin \
    klipper-canvas.bin \
    FIRMWARE_SHA256SUMS.txt
do
    [ -f "$SCRIPT_DIR/$required" ] || die "Missing bundle file: $required"
done

find_single_device() {
    if [ -n "$DEVICE_ARG" ]; then
        [ -e "$DEVICE_ARG" ] || die "Device does not exist: $DEVICE_ARG"
        printf '%s\n' "$DEVICE_ARG"
        return
    fi

    set -- /dev/ttyACM*
    if [ "$1" = '/dev/ttyACM*' ]; then
        die "No /dev/ttyACM device found. Check CANVAS 24 V power and USB wiring."
    fi
    [ "$#" -eq 1 ] || die "Multiple ACM devices found. Re-run with --device /dev/ttyACMx"
    printf '%s\n' "$1"
}

wait_for_device() {
    preferred=$1
    attempt=0
    while [ "$attempt" -lt 20 ]; do
        if [ -e "$preferred" ]; then
            printf '%s\n' "$preferred"
            return 0
        fi
        set -- /dev/ttyACM*
        if [ "$1" != '/dev/ttyACM*' ] && [ "$#" -eq 1 ]; then
            printf '%s\n' "$1"
            return 0
        fi
        attempt=$((attempt + 1))
        sleep 1
    done
    return 1
}

usb_id() {
    resolved=$(readlink -f "$1" 2>/dev/null || true)
    [ -n "$resolved" ] || {
        printf '%s\n' unknown
        return
    }
    tty_name=$(basename "$resolved")
    node=$(readlink -f "/sys/class/tty/$tty_name/device" 2>/dev/null || true)
    while [ -n "$node" ] && [ "$node" != "/" ]; do
        if [ -r "$node/idVendor" ] && [ -r "$node/idProduct" ]; then
            vendor=$(tr 'A-F' 'a-f' < "$node/idVendor")
            product=$(tr 'A-F' 'a-f' < "$node/idProduct")
            printf '%s:%s\n' "$vendor" "$product"
            return
        fi
        parent=$(dirname "$node")
        [ "$parent" != "$node" ] || break
        node=$parent
    done
    printf '%s\n' unknown
}

DEVICE=$(find_single_device)
USB_ID=$(usb_id "$DEVICE")

echo "Detected serial device: $DEVICE"
echo "Detected USB ID:       $USB_ID"

case "$USB_ID" in
    1d50:614e)
        echo
        echo "CANVAS already identifies as a Klipper USB MCU."
        echo "No first-time flash is required, so nothing was changed."
        exit 0
        ;;
    1d50:6177)
        FLASH_STAGE="katapult"
        ;;
    *)
        FLASH_STAGE="stock"
        ;;
esac

# The base AD5M chroot's /usr/bin/python3 does not expose pyserial directly,
# but the installed Klipper virtual environment does. Prefer that interpreter
# and retain system Python as a fallback for other compatible Linux hosts.
FLASH_PYTHON=""
for candidate in \
    /root/printer_software/klipper/klippy-env/bin/python3 \
    python3
do
    if "$candidate" -c 'import serial' >/dev/null 2>&1; then
        FLASH_PYTHON=$candidate
        break
    fi
done
[ -n "$FLASH_PYTHON" ] || die "pyserial was not found in the Klipper environment or system Python"
echo "Flashing Python:       $FLASH_PYTHON"

if command -v fuser >/dev/null 2>&1; then
    BUSY=$(fuser "$DEVICE" 2>/dev/null || true)
    [ -z "$BUSY" ] || die "Device is in use by process(es): $BUSY"
fi

cat <<EOF

This operation permanently overwrites the Elegoo CANVAS application firmware.
There is no captured backup of the original application for this unit.

Required wiring:
  CANVAS DM  -> USB D-
  CANVAS DP  -> USB D+
  CANVAS GND -> USB GND
  USB 5 V    -> NOT CONNECTED to CANVAS 24 V
  CANVAS 24 V/GND -> separately validated 24 V supply

Do not disconnect USB or power during either flashing stage.
EOF

if [ "$ASSUME_YES" -ne 1 ]; then
    printf '\nType FLASH CANVAS to continue: '
    IFS= read -r confirmation
    [ "$confirmation" = "FLASH CANVAS" ] || die "Confirmation did not match; nothing changed"
fi

STAGE_DIR=$(mktemp -d /tmp/canvas-flasher.XXXXXX)
case "$STAGE_DIR" in
    /tmp/canvas-flasher.*) ;;
    *) die "Unexpected temporary directory: $STAGE_DIR" ;;
esac
cleanup() {
    case "$STAGE_DIR" in
        /tmp/canvas-flasher.*) rm -rf -- "$STAGE_DIR" ;;
    esac
}
trap cleanup EXIT HUP INT TERM

cp "$SCRIPT_DIR/mcu-flasher-linux-armv7" "$STAGE_DIR/"
cp "$SCRIPT_DIR/flashtool.py" "$STAGE_DIR/"
cp "$SCRIPT_DIR/katapult-deployer-canvas.bin" "$STAGE_DIR/"
cp "$SCRIPT_DIR/klipper-canvas.bin" "$STAGE_DIR/"
cp "$SCRIPT_DIR/FIRMWARE_SHA256SUMS.txt" "$STAGE_DIR/"
chmod 0755 "$STAGE_DIR/mcu-flasher-linux-armv7" "$STAGE_DIR/flashtool.py"

echo
echo "Verifying bundled files..."
(cd "$STAGE_DIR" && sha256sum -c FIRMWARE_SHA256SUMS.txt)

if [ "$FLASH_STAGE" = "stock" ]; then
    echo
    echo "Stage 1 of 2: installing the Katapult deployer..."
    "$STAGE_DIR/mcu-flasher-linux-armv7" \
        --canvas \
        --timeout 10 \
        --firmware "$STAGE_DIR/katapult-deployer-canvas.bin" \
        --no-wait \
        --firmware-version 6.4.9 \
        "$DEVICE"

    sleep 3
    DEVICE=$(wait_for_device "$DEVICE") || die "CANVAS did not reconnect after the Katapult deployer"
    USB_ID=$(usb_id "$DEVICE")
    echo "CANVAS reconnected as $DEVICE ($USB_ID)"
else
    echo
    echo "Katapult is already present; skipping stage 1."
fi

echo
echo "Stage 2 of 2: flashing the CANVAS Klipper application..."
"$FLASH_PYTHON" "$STAGE_DIR/flashtool.py" \
    -d "$DEVICE" \
    -f "$STAGE_DIR/klipper-canvas.bin"

sleep 3
DEVICE=$(wait_for_device "$DEVICE") || die "CANVAS did not reconnect after the Klipper flash"
USB_ID=$(usb_id "$DEVICE")

echo
if [ "$USB_ID" = "1d50:614e" ]; then
    echo "SUCCESS: CANVAS now identifies as a Klipper USB MCU on $DEVICE."
    echo "Next step: install the compatible CANVAS host modules/configuration on the AD5M."
else
    echo "The flash command completed, but the expected Klipper USB ID was not confirmed."
    echo "Detected: $DEVICE ($USB_ID)"
    echo "Do not continue with printer-host installation until this is investigated."
    exit 2
fi
